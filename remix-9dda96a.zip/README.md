# Automatic build
Built website from `9dda96a`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `remix-9dda96a.zip`.
